package oop;

public class Car extends Vehicle {

    static double SUMMER_EXTRA_CONSUPTION  = 0.9;

    public Car(double fuelQuantity, double fuelConsuptionPerKm) {
        super(fuelQuantity, fuelConsuptionPerKm);
    }

    @Override
    public void setFuelConsuptionPerKm(double fuelConsuptionPerKm) {
        super.setFuelConsuptionPerKm(fuelConsuptionPerKm + SUMMER_EXTRA_CONSUPTION) ;
    }

}