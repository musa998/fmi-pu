package oop;

public abstract class  Vehicle {

    private double fuelQuantity;
    private   double fuelConsuptionPerKm;
    private double drivenDistance;
    private   double liters;

    public Vehicle(double fuelQuantity, double fuelConsuptionPerKm) {
        setFuelQuantity(fuelQuantity);
        setFuelConsuptionPerKm(fuelConsuptionPerKm);
    }
    public  boolean drive(double distance){
        double neededFuel = distance * this.fuelConsuptionPerKm;
        if (getFuelQuantity() > neededFuel){
            this.fuelQuantity -= neededFuel;
            return true;
        }
        return false;
    }

    public  void refueled(double liters){
        this.fuelQuantity += liters;
    }



    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    public double getFuelConsuptionPerKm() {
        return fuelConsuptionPerKm;
    }

    public void setFuelConsuptionPerKm(double fuelConsuptionPerKm) {
        this.fuelConsuptionPerKm = fuelConsuptionPerKm;
    }

    public double getDrivenDistance() {
        return drivenDistance;
    }

    public void setDrivenDistance(double drivenDistance) {
        this.drivenDistance = drivenDistance;
    }

    public double getLiters() {
        return liters;
    }

    public void setLiters(double liters) {
        this.liters = liters;
    }
}
