package oop;

public abstract class Feline extends Mammal {
    public Feline(String name, String type, double weight, String livingRegion) {
        super(name, type, weight, livingRegion);
    }
}
