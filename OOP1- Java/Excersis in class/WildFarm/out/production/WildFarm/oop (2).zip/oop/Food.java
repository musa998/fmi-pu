package oop;

public abstract class Food {
    int quantity;

    public Food(int quantity) {
        this.quantity = quantity;
    }
}
