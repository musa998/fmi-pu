package oop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));


        while (true){
            String[] animalToknes = reader.readLine().split(" ");
            if (animalToknes.equals("End")) return;
            String[] foodTokens = reader.readLine().split(" ");

            switch (animalToknes[0]){
                case "Cat":
                    Mammal cat = new Cat(animalToknes[1], animalToknes[0], Double.parseDouble(animalToknes[2]),
                            (animalToknes[3]), animalToknes[4]);
                   if (foodTokens[0].equals("Vegetable")){
                       Food food =  new Vegetable(Integer.parseInt(foodTokens[1]));
                       cat.eat(food);
                   }
                   else if (foodTokens[0].equals("Meat")){
                       Food food = new Meat(Integer.parseInt(foodTokens[1]));
                       cat.eat(food);
                   }
                   cat.makeSound();
                    System.out.println(cat.toString());
                    break;
                case "Tiger":
                    Animal tiger  = new Tiger(animalToknes[1], animalToknes[0],
                            Double.parseDouble(animalToknes[2]), (animalToknes[3]));
                    if (foodTokens[0].equals("Vegetable")){
                        Food food =  new Vegetable(Integer.parseInt(foodTokens[1]));
                        tiger.eat(food);
                    }
                    else if (foodTokens[0].equals("Meat")){
                        Food food = new Meat(Integer.parseInt(foodTokens[1]));
                        tiger.eat(food);
                    }
                    tiger.makeSound();
                    System.out.println(tiger.toString());
                    break;
                case "Zebra":
                    Animal zebra = new Zebra(animalToknes[1], animalToknes[0],
                            Double.parseDouble(animalToknes[2]), (animalToknes[3]));
                    if (foodTokens[0].equals("Vegetable")){
                        Food food =  new Vegetable(Integer.parseInt(foodTokens[1]));
                        zebra.eat(food);
                    }
                    else if (foodTokens[0].equals("Meat")){
                        Food food = new Meat(Integer.parseInt(foodTokens[1]));
                        zebra.eat(food);
                    }
                    zebra.makeSound();
                    System.out.println(zebra.toString());
                    break;
                case "Mouse":
                    Animal mouse = new Mouse(animalToknes[1], animalToknes[0],
                            Double.parseDouble(animalToknes[2]), (animalToknes[3]));
                    if (foodTokens[0].equals("Vegetable")){
                        Food food =  new Vegetable(Integer.parseInt(foodTokens[1]));
                        mouse.eat(food);
                    }
                    else if (foodTokens[0].equals("Meat")){
                        Food food = new Meat(Integer.parseInt(foodTokens[1]));
                        mouse.eat(food);
                    }
                    mouse.makeSound();
                    System.out.println(mouse.toString());
                    break;
            }






        }


    }
}
